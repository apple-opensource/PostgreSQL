DO $$ plpy.notice("This is plpythonu.") $$ LANGUAGE plpythonu;

DO $$ nonsense $$ LANGUAGE plpythonu;
